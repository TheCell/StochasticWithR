#######################################################################
##                                                                   ##
##                      Standortbestimmung                           ##
##                                                                   ##
#######################################################################


# Aufgabe 1 a

# Aufgabe 1 b

...

# Quizfragen

# Einlesen der Daten-Datei Schokolade_Nobelpreis.txt
# Daten-File und R-Script File name_vorname.R
# m??ssen im selben Verzeichnis sein

datei <- read.table(file="./Schokolade_Nobelpreis.txt", header=TRUE)
  